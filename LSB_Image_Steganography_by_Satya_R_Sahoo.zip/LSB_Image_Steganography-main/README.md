LSB IMAGE STEGANOGRAPHY by SATYA RANJAN SAHOO

This C program implements a basic LSB (Least Significant Bit) image steganography technique. LSB steganography involves hiding secret information in the least significant bits of the pixel values in an bmp type image.


Compile the program using a GCC compiler:

       1. gcc *.c
       2. ./a.out -e beautiful.bmp secret.txt stego.bmp  --> For Encoding
       3. ./a.out -d stego.bmp decode.txt  --> For Decoding
